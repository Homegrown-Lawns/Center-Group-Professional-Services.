# Center Group Professional Services — GitHub Pages Web 2.0

Upload `index.html`, `style.css`, `script.js`, and `logo.svg` to a GitHub Pages repository.

The site uses responsive HTML/CSS/JavaScript, Font Awesome, local SVG branding, Google Maps embeds, schema markup, FAQ accordions, blog modals, mobile navigation, animations, and floating Call/WhatsApp buttons.

Before publishing, replace the sample review text with verified customer reviews and update the canonical URL if the final GitHub Pages domain differs from the business domain.
