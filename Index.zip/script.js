const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");

menuToggle.addEventListener("click", () => {
  const open = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", open);
  menuToggle.innerHTML = open
    ? '<i class="fa-solid fa-xmark"></i>'
    : '<i class="fa-solid fa-bars"></i>';
});

document.querySelectorAll("#mainNav a").forEach(link => {
  link.addEventListener("click", () => {
    mainNav.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.innerHTML = '<i class="fa-solid fa-bars"></i>';
  });
});

const revealItems = document.querySelectorAll(".reveal");
const observer = new IntersectionObserver((entries, obs) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("visible");
      obs.unobserve(entry.target);
    }
  });
}, {threshold: 0.12});
revealItems.forEach(item => observer.observe(item));

const sections = document.querySelectorAll("main section[id], header[id]");
const navLinks = document.querySelectorAll(".nav a");
window.addEventListener("scroll", () => {
  let current = "home";
  sections.forEach(section => {
    if (window.scrollY >= section.offsetTop - 130) current = section.id;
  });
  navLinks.forEach(link => {
    link.classList.toggle("active", link.getAttribute("href") === `#${current}`);
  });
});

const posts = {
  post1: {
    category: "Cleaning Guide",
    title: "When Should You Schedule Pressure Washing for Your Property?",
    paragraphs: [
      "Exterior surfaces are exposed to rain, dust, humidity, foot traffic, and everyday activity. Over time, these conditions can leave driveways, patios, walls, and other suitable surfaces looking dull or dirty.",
      "A practical time to schedule cleaning is when visible buildup begins to affect the appearance of the property. Regular exterior care can also make it easier to notice cracks, stains, damaged areas, or other maintenance concerns.",
      "The right cleaning method depends on the surface. Durable materials may be suitable for pressure washing, while more delicate surfaces may call for a lower-pressure soft washing approach."
    ]
  },
  post2: {
    category: "Roof Care",
    title: "Why Roof Cleaning Matters for Property Appearance",
    paragraphs: [
      "The roof is one of the largest visible parts of a property. Dirt and organic buildup can change its appearance and make an otherwise maintained building look less clean.",
      "Roof cleaning should be approached with care because roofing materials can vary. The cleaning method should be selected based on the roof type, condition, and the type of buildup present.",
      "Professional roof cleaning can be part of a broader exterior maintenance plan that also includes house washing, gutters, windows, driveways, and outdoor living areas."
    ]
  },
  post3: {
    category: "Outdoor Spaces",
    title: "How to Keep Driveways, Patios, and Decks Looking Clean",
    paragraphs: [
      "Driveways, patios, and decks receive regular exposure to weather, dirt, leaves, spills, and foot traffic. Because these surfaces are highly visible, buildup can quickly affect the overall appearance of a property.",
      "Routine cleaning helps keep outdoor areas presentable. Before cleaning, the surface material should be considered so the method and pressure are appropriate for the area.",
      "For pool patios and decks, careful surface cleaning is especially useful because these spaces are commonly used for relaxation and entertaining. A consistent maintenance routine can help keep outdoor areas ready for use."
    ]
  }
};

const modal = document.getElementById("postModal");
const modalTitle = document.getElementById("modalTitle");
const modalCategory = document.getElementById("modalCategory");
const modalText = document.getElementById("modalText");

document.querySelectorAll(".read-more").forEach(button => {
  button.addEventListener("click", () => {
    const post = posts[button.dataset.modal];
    if (!post) return;
    modalCategory.textContent = post.category;
    modalTitle.textContent = post.title;
    modalText.innerHTML = post.paragraphs.map(p => `<p>${p}</p>`).join("");
    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
  });
});

function closeModal() {
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
}
document.querySelectorAll("[data-close]").forEach(el => el.addEventListener("click", closeModal));
document.addEventListener("keydown", e => {
  if (e.key === "Escape" && modal.classList.contains("open")) closeModal();
});
